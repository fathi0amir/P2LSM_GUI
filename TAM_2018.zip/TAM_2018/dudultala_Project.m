% ============================== Clean up ============================== %
clear
clc

% ======================== Constants declaration ======================= %
MIN_VOL =  -5;
MAX_VOL =   5;

% ============================ Main Program ============================ %
% Read the image data
my_data    = imread('dudultala2.bmp');
resolution = size(my_data, 1);

% Get indices of non-zero elements
[row, col] = find(my_data);

row = repelem(row, 10);
col = repelem(col, 10);

assert(length(row) == length(col));

% Compute voltages for non-zero elements
vol_x = MIN_VOL + row*(MAX_VOL-MIN_VOL)/resolution;
vol_y = MIN_VOL + col*(MAX_VOL-MIN_VOL)/resolution;

% Write back in CSV file
csvwrite('voltage_image2.csv', [vol_x vol_y]);
csvwrite('voltage_image_ind.csv', [row col]);

% Plot signals
plot(vol_x);
hold on;
plot(vol_y);
xlabel('Non-zero elements in the bitmap') ;
ylabel('Voltage (V)');
legend({'Voltage on x','Voltage on y'},'Location','southeast');
title('Voltages to display the image');
ax          = gca;
ax.FontSize = 13;


